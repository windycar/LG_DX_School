#!/usr/bin/env python
# coding: utf-8

# In[1]:


def add_num(num1,num2):
    return num1+num2


# In[2]:


def sub_num(num1,num2):
    return num1-num2


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




